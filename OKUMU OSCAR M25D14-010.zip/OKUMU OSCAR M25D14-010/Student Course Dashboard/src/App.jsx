import { useMemo, useState } from 'react';
import courses from './data/courses';

function CourseCard({ course }) {
  return (
    <article className="course-card">
      <div className="course-card-top">
        <span className="course-code">{course.code}</span>
        <span className={course.completed ? 'status completed' : 'status progress'}>
          {course.completed ? 'Completed' : 'In progress'}
        </span>
      </div>
      <div className="course-icon" aria-hidden="true">{course.title.slice(0, 1)}</div>
      <h2>{course.title}</h2>
      <p className="lecturer">Lecturer: {course.lecturer}</p>
      <p className="description">{course.description}</p>
      <div className="progress-heading">
        <span>Course progress</span>
        <strong>{course.progress}%</strong>
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-label={`${course.title} progress`}
        aria-valuenow={course.progress}
        aria-valuemin="0"
        aria-valuemax="100"
      >
        <span style={{ width: `${course.progress}%` }} />
      </div>
    </article>
  );
}

export default function App() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All courses');

  const visibleCourses = useMemo(() => courses.filter((course) => {
    const matchesSearch = `${course.title} ${course.lecturer} ${course.code}`
      .toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'All courses'
      || (filter === 'Completed' && course.completed)
      || (filter === 'In progress' && !course.completed);
    return matchesSearch && matchesFilter;
  }), [search, filter]);

  const completedCount = courses.filter((course) => course.completed).length;
  const averageProgress = Math.round(
    courses.reduce((total, course) => total + course.progress, 0) / courses.length,
  );

  return (
    <main className="dashboard">
      <header className="welcome">
        <div>
          <p className="eyebrow">STUDENT PORTAL</p>
          <h1>My Course Dashboard</h1>
          <p className="welcome-copy">Keep track of your courses and see how far you have come.</p>
        </div>
        <div className="avatar" aria-label="Student profile">S</div>
      </header>

      <section className="summary" aria-label="Course summary">
        <div className="summary-card">
          <span className="summary-label">Total courses</span>
          <strong>{courses.length}</strong>
          <span className="summary-note">Courses enrolled</span>
        </div>
        <div className="summary-card">
          <span className="summary-label">Completed</span>
          <strong>{completedCount}</strong>
          <span className="summary-note">Course finished</span>
        </div>
        <div className="summary-card">
          <span className="summary-label">Average progress</span>
          <strong>{averageProgress}%</strong>
          <span className="summary-note">Across all courses</span>
        </div>
      </section>

      <section className="courses-section">
        <div className="section-heading">
          <div>
            <h2>Your courses</h2>
            <p>Review your current learning progress.</p>
          </div>
          <span className="course-count">{visibleCourses.length} shown</span>
        </div>

        <div className="course-tools">
          <label className="search-label">
            <span>Search courses</span>
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by course, lecturer or code"
            />
          </label>
          <label className="filter-label">
            <span>Filter by status</span>
            <select value={filter} onChange={(event) => setFilter(event.target.value)}>
              <option>All courses</option>
              <option>In progress</option>
              <option>Completed</option>
            </select>
          </label>
        </div>

        {visibleCourses.length > 0 ? (
          <div className="course-grid">
            {visibleCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon" aria-hidden="true">?</div>
            <h3>No courses found</h3>
            <p>Try another search term or change the status filter.</p>
            <button type="button" onClick={() => { setSearch(''); setFilter('All courses'); }}>
              Clear filters
            </button>
          </div>
        )}
      </section>

      <footer>Student Course Dashboard <span>•</span> Keep learning, one step at a time.</footer>
    </main>
  );
}
