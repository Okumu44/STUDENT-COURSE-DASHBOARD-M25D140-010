const courses = [
  {
    id: 1,
    title: 'Web Development',
    lecturer: 'Dr. Kato',
    progress: 70,
    completed: false,
    description: 'Build and style modern websites using HTML, CSS and JavaScript.',
    code: 'BIT 2101',
  },
  {
    id: 2,
    title: 'Database Systems',
    lecturer: 'Ms. Auma',
    progress: 100,
    completed: true,
    description: 'Learn how to organise, query and manage data in relational databases.',
    code: 'BIT 2102',
  },
  {
    id: 3,
    title: 'Computer Networks',
    lecturer: 'Mr. Okello',
    progress: 45,
    completed: false,
    description: 'Understand network devices, protocols and how computers communicate.',
    code: 'BIT 2103',
  },
];

export default courses;
