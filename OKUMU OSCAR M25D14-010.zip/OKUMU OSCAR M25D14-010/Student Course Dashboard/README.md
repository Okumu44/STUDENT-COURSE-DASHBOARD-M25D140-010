# Student Course Dashboard

## Open the webpage immediately
Open `index.html` in Chrome, Edge, or Firefox. This standalone preview does not need Node.js or an internet connection. Search and status filters work.

## Open and view the code in VS Code
1. Download and extract the ZIP file first. Do not try to edit the ZIP preview.
2. In VS Code, select **File → Open Folder**.
3. Choose the extracted `Student_Course_Dashboard_Fixed` folder.
4. In the Explorer panel, open `src`, then `App.jsx`, `main.jsx`, `styles.css`, and `data/courses.js`.
5. The top-level `index.html` is the standalone preview. The `src` folder contains the React assignment source.

## Run the React version
Install Node.js LTS first. Open the VS Code terminal in this folder and run:

```bash
npm install
npm run dev
```

Open the local address printed by Vite. The React version uses a reusable `CourseCard` component with props, course data from an array, `map()` with stable keys, conditional status labels, an empty state, search, status filtering, and responsive CSS.

If `npm install` fails, use the top-level `index.html` preview while fixing the network or Node.js setup. The standalone preview is provided as a fallback; submit the React source files for the JSX/components learning outcomes.
